#include <iostream>
#include<cstring>
#include "own.h"
#include "copy.h"
#include "cow.h"
#include <string.h>
#include <stdlib.h>
#include <cstdlib>
#include <stdio.h>
#include "StringBuffer.h"
#include "String.h"


using namespace std;
         int note =0;
int i=0; 


void noteCOWL(){
cout<<"\n\ncopy on write linking...." <<endl;
note = 0;
       str_ref* refptr1 = new str_ref();
	refptr1->reserve(18);
	refptr1->append('m');
	refptr1->append('a');
	refptr1->append('z');
	refptr1->append('h');
	refptr1->append('a');
	cout<<"refptr1 _length = "<<refptr1->_length()<<endl;
	refptr1->append('f');        
cout<<"refptr1 _length = "<<refptr1->_length()<<endl;

	str_ref* refptr2 = new str_ref();
	refptr2->reserve(18);
	*refptr1 = *refptr2;
if(note!=1)
cout<<"refptr2 _length = "<<refptr2->_length()<<endl;

i=0;



while(i<5){

	{
		if(refptr1->charAt(i) != refptr2->charAt(i))
		{
	                cout<<"copy on write linking test not working...."<<endl;
			note = 1;
		}
	}

i++;
}		
if(note!=1)
cout <<"copy on write link working successfully...."<<endl;

}


void noteOwnPointer(){

    cout<<"Owned pointers...." <<endl;
	ownedpointers* opobj = new ownedpointers();
	opobj->reserve(18);
	opobj->append('m');
        opobj->append('a');
	opobj->append('z');
	opobj->append('h');
	opobj->append('r');

	cout<<"opobj _length = "<<opobj->_length()<<std::endl;

	ownedpointers* opobj2 = new ownedpointers(*opobj);
	opobj2->reserve(18);
	*opobj2 = *opobj;

	cout<<"opobj2 _length = "<<opobj2->_length()<<std::endl;
     //test of owned pointers

      while(i<5){
	
	
		if(opobj->charAt(i) != opobj2->charAt(i))
		{
			cout<<"Owned pointers not working...."<<endl;
			note = 1;
		}
	
        i++;
}
	if(note!=1)
		cout <<"Owned pointers working...."<<endl;
	


}

void noteRefCount(){


     cout<<"\n\ncopy on write with hello counting..."<<endl;
    char* hello = new char;
    hello[0]='c';
    String newStr2(hello,9);
    cout<<"newStr2 _length = "<<newStr2._length()<<std::endl;
    cout<<hello<<endl;
    String newStr(newStr2);
    cout<<hello<<endl;
    cout<<"newStr _length = "<<newStr._length()<<endl;
    cout<<"new newStr charAt 0 = "<<newStr.charAt(0)<<endl;
    newStr2.append('l');
    cout<<"new newStr _length = "<<newStr._length()<<endl;
    cout<<"new newStr2 _length = "<<newStr2._length()<<endl;
}


void noteCopyPointer(){

  note = 0; 
 	cout<<"\n\nCopied Pointer...." <<endl;

       copiedpointers cpobj;
	cpobj.reserve(18);
	cpobj.append('m');
	cpobj.append('a');
        cpobj.append('z');
         cpobj.append('h');

        cout<<"cpobj _length = "<<cpobj._length()<<std::endl;
	
       copiedpointers cp3(cpobj);
cout<<"cp3 _length = "<<cp3._length()<<endl;
	i=0;


while(i<4){
	{
		if(cpobj.charAt(i) != cp3.charAt(i))
		{
			cout<<"Copied pointers not working...."<<endl;
			note = 1;
		}
	}
   i++;
}
if(note!=1)
cout <<"Copied pointer are working properly...."<<endl;




}



int main(int argc, char** argv) {
  
   noteCOWL();
   noteOwnPointer();
noteRefCount();
noteCopyPointer();
    



    return 0;
}
