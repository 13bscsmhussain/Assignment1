#include <iostream>
#include<cstring>
#include <cstdlib>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "StringBuffer.h"
#include "String.h"

class copiedpointers{ //class of copied pointers

private:
	
    int _length;            //_length variable                           

    char* _strbuf;       // pointer to character                          
    
public :
copiedpointers(char* str,int _length)
{
    _strbuf = str;
    this._length = _length;
}
int _length() const{ //function to return _length of string
	return this._length;
}

void append(char _letter_) //function to append a character at the end 
{
	_strbuf[_length] = _letter_;
	_length += 1;
}

copiedpointers(const copiedpointers& tmp) //constructor 
{
    _strbuf = new char [tmp._length];	//assigning memory locaton of size _length  
    strcpy(_strbuf, tmp._strbuf);		//copying strings
    _length = tmp._length;       
}

copiedpointers& operator= (const copiedpointers &tmp )
    { 
        if (this != &tmp)
        {
            delete[] _strbuf;
            _strbuf = new char [tmp._length];
            strcpy(_strbuf, tmp._strbuf);
           this._length = tmp._length;       
        }
        return *this;
    }



char charAt(int indexpoint) const //getting character at indexpoint 
{
	return _strbuf[indexpoint];
}


void reserve(int indexpoint) //getting character at indexpoint
{
	_strbuf = new char[indexpoint];
}


     copiedpointers(char* ch = 0) throw()     : _strbuf(ch) 
     {
        _length = 0;
     }


~copiedpointers()   //destructor for copied pointer class
{

    delete[] _strbuf;
   
}
};

