
#include <iostream>
#include<cstring>
#include <cstdlib>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "StringBuffer.h"
#include "String.h"

class ownedpointers{		//class of owned pointers

private:
 	char* _strbuf;                                   
        int _length;
	bool owned;
        

public :
    
  int _length() const{ //function to return _length of string
	return this._length;
}

void reserve(int indexpoint)  //function to reserve memory
{
	_strbuf = new char[indexpoint]; //allocating memory
}

ownedpointers(char* str,int _length) //constructor of owned pointer class, passing a string of characters and _length to it
{
    _strbuf = str;
    this._length = _length;
}

    ownedpointers(char* ch = 0) throw(): owned(ch!=0), _strbuf(ch) {}


void append(char ltr) //function to append a character at the end 
{
	_strbuf[this._length] = ltr;
	this._length += 1;
}

char charAt(int indexpoint) const //getting character at indexpoint 
{
	return _strbuf[indexpoint];
}

                   
    ~ownedpointers()  //destructor for owned pointer class
{
	if (owned)
	{
		delete[] _strbuf;
	}
	delete _strbuf;
	
}

 


    ownedpointers& operator =(const ownedpointers &newvar )
    { 

    	if (&newvar != this) {
            if (_strbuf != newvar._strbuf)
            {
                if (owned)
                {
                	delete[] _strbuf;
                	delete _strbuf;
                }
                owned = newvar.owned;
            }
            else if (newvar.owned) owned = true;
            delete[] _strbuf;
            _strbuf = newvar.release();

            this._length = newvar._length;
        }

        return *this;
    }

     
     ownedpointers(const ownedpointers& newvar) throw(): owned(newvar.owned), _strbuf(newvar.release()) 
	{
	}

 char* release()  const throw()
    {
    	(const_cast<ownedpointers* >(this))->owned = false; 
    	return _strbuf;
    }

};

