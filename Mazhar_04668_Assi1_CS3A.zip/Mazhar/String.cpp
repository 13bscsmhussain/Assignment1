#include "StringBuffer.h"
#include "String.h"
#include <memory>
#include <iostream>



using namespace std;

String::String() {
    this->_str = new StringBuffer();
}
String::~String() {

    if (--this->_str->_refcount < 1) {
        delete[] this->_str;
    }

}

String::String(const String& newString) {
    this->_str = newString._str;
    ++this->_str->_refcount;
}

String::String(char* newString, int length) {
    this->_str = new StringBuffer(newString, length);
    this->_str->_refcount = 1;

}

void String::append(char c) {
    if (this->_str->_refcount > 1) {
        auto_ptr<StringBuffer> newdata(new StringBuffer);
        newdata.get()->reserve(this->_str->length() + 1);
        newdata.get()->smartCopy(this->_str);
        --this->_str->_refcount;
        this->_str = newdata.release();
    } else {
        this->_str->reserve(this->_str->length() + 1);
    }
    this->_str->append(c);
}
int String::length() const {
    return this->_str->length();
}
char String::charAt(int index) const {
    if (index < this->_str->length()) {
        return this->_str->charAt(index);
    } else {
//exception
    }
}
