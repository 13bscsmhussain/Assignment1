#include <iostream>
#include<cstring>
#include <cstdlib>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "StringBuffer.h"
#include "String.h"

class str_ref{	//class for copy on write reference linking

private:
                                     
    char*    _strbuf; 
    int _length;
    
    str_ref*   previous_ptr;
    str_ref*   next_ptr;
    
    void Fetch(const str_ref& newvar) throw()
    { // insert this to the list
        _strbuf = newvar._strbuf;
        this._length = newvar._length;
        next_ptr = newvar.next_ptr;
        next_ptr->previous_ptr = this;
        //*previous_ptr = newvar;
        (const_cast<str_ref*>(&newvar))->next_ptr = this;
    }

public :
    
int _length() const{ //function to return _length of string
	return this._length;
}

void reserve(int indexpoint) //getting character at indexpoint
{
	_strbuf = new char[indexpoint];
}

char charAt(int indexpoint) const //getting character at indexpoint 

{
	return _strbuf[indexpoint];
}


    char* get() const throw()   {return _strbuf;}
    

	str_ref(const str_ref& newvar)
	{
        Fetch(newvar);
        this._length = newvar._length;
        
	}


    str_ref& operator= (const str_ref &newvar )
    { 

    	if (this != &newvar) {
            rel();
            Fetch(newvar);
        }
        return *this;
    }

    bool unique()   const throw()  
     {
     	if(previous_ptr == this && next_ptr == this)
     		return 1;
     	else
     		return 0;
     }

void append(char _letter_) //function to append a character at the end 
{
	if(unique())
	{
		
		_strbuf[_length] = _letter_;
		_length += 1;
	}
	else
	{
		char* temp = new char[_length];
		strncpy(temp,_strbuf,_length);
		rel();
		_strbuf = new char[_length];
		strncpy(_strbuf,temp,_length);
		_strbuf[_length] = _letter_;
		_length += 1;
		delete[] temp;
		next_ptr = previous_ptr = this;

	}
	
}
    

str_ref(str_ref* p = 0) throw()   : _strbuf(0) 
    {
        previous_ptr = next_ptr = this;
    }

 void rel()
    { // erase this from the list, delete if unique
        if (unique()) 
        	delete[] _strbuf;
        else
        {
            previous_ptr->next_ptr = next_ptr;
            next_ptr->previous_ptr = previous_ptr;
            previous_ptr = next_ptr = 0;
            //delete[] _strbuf;
        }
       
    }

  ~str_ref()   //destructor for copied pointer class
{
       rel();

}

   };


